function login(){
    var name = document.getElementById("name").value
    var family = document.getElementById("family").value
    alert(name + " " + family + " " +  "عزیز ثبت نام شما با موفقیت انجام شد.")
}